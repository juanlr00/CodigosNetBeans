/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.proyectocrud;

import model.Comandas;

/**
 *
 * @author JuanLamasRubio
 */
public class PrincipalCarta {
    public static void main(String[] args) {
        var DAO = new ComandaDAO();
        
        Comandas c = new Comandas(3434,"Preparar pedido","Juan","Disponible","Importante");
    }
}
